DROP TYPE tdinc.extract;
DROP TYPE tdinc.feed;
DROP TYPE tdinc.fhconf;

@C:/cygwin/home/brysons/source/framework/trunc/types/NOTIFY.tps
@C:/cygwin/home/brysons/source/framework/trunc/types/NOTIFY.tpb
@C:/cygwin/home/brysons/source/framework/trunc/types/FILECONF.tps
@C:/cygwin/home/brysons/source/framework/trunc/types/FILECONF.tpb
@C:/cygwin/home/brysons/source/framework/trunc/types/EXTRACT.tps
@C:/cygwin/home/brysons/source/framework/trunc/types/EXTRACT.tpb
@C:/cygwin/home/brysons/source/framework/trunc/types/FEED.tps
@C:/cygwin/home/brysons/source/framework/trunc/types/FEED.tpb
